실행하기
```batch
uvicorn main:app --reload
```

Requirements
```batch
pip install -r requirements.txt
```